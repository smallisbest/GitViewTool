gt (GitViewTool) latest — standalone macOS build

Install:
  1. Install FUSE-T (one-time, only if you plan to use `gt mount`):
       brew install --cask macos-fuse-t/cask/fuse-t
  2. Move this directory wherever you like and symlink the binary:
       ln -s "$(pwd)/bin/gt" /usr/local/bin/gt

Verify:
  gt --version-long

Docs:
  https://smallisbest.github.io/gct/

Source:
  https://github.com/smallisbest/gct
